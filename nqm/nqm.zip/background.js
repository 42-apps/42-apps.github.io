// Network Quality Monitor — background service worker.
// Probes the network on a schedule, classifies VoIP readiness, paints the toolbar
// icon (green / amber / red / grey), and raises notifications on degradation.

import { STATES, ENDPOINTS, classify, median, jitterOf, fmtMs, fmtPct, fmtMos } from './lib/metrics.js';

const ALARM = 'nqm-probe';
const DEFAULTS = {
  intervalSec: 30,
  endpoint: 'auto',
  notifyDegrade: true,
  notifyRecover: true,
  showBadge: true,
  paused: false,
};
const BURST = { samples: 16, gapMs: 160, timeoutMs: 1800, warmupTimeoutMs: 2500 };
const LIVE_GAP_MS = 4500;      // probe cadence while the popup is open
const RECENT_BURSTS = 3;       // loss is smoothed over this many bursts (48 samples)
const HISTORY_MAX = 2880;      // ~24 h at 30 s
const NOTIFY_COOLDOWN_MS = 60_000;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const livePorts = new Set();
let liveLoopRunning = false;
let inflight = null;
let probeSeq = 0;

// ---------------------------------------------------------------- settings

async function getSettings() {
  const { settings } = await chrome.storage.local.get('settings');
  return { ...DEFAULTS, ...(settings || {}) };
}

function endpointOrder(settings) {
  const auto = ['google', 'cloudflare', 'gdns', 'google2'];
  const ids = settings.endpoint === 'auto'
    ? auto
    : [settings.endpoint, ...auto.filter((id) => id !== settings.endpoint)];
  return ids.map((id) => ENDPOINTS.find((e) => e.id === id)).filter(Boolean);
}

// ---------------------------------------------------------------- probing

function bust(url) {
  return url + (url.includes('?') ? '&' : '?') + 'nqm=' + Date.now().toString(36) + (probeSeq++);
}

async function probeOnce(url, timeoutMs) {
  const ctrl = new AbortController();
  const tid = setTimeout(() => ctrl.abort(), timeoutMs);
  const t0 = performance.now();
  try {
    const res = await fetch(bust(url), {
      cache: 'no-store',
      credentials: 'omit',
      redirect: 'manual',
      signal: ctrl.signal,
    });
    await res.arrayBuffer().catch(() => {});
    return performance.now() - t0;
  } catch {
    return null;
  } finally {
    clearTimeout(tid);
  }
}

async function runBurst(order) {
  // Warm-up probe doubles as endpoint selection and absorbs the TLS/TCP handshake,
  // so the timed samples below measure steady-state round trips.
  let endpoint = null;
  for (const e of order) {
    if ((await probeOnce(e.url, BURST.warmupTimeoutMs)) != null) { endpoint = e; break; }
  }
  const t = Date.now();
  if (!endpoint) return { t, offline: true, total: BURST.samples, lost: BURST.samples, rtts: [], endpointId: null };

  const rtts = [];
  let lost = 0;
  for (let i = 0; i < BURST.samples; i++) {
    const t0 = performance.now();
    const rtt = await probeOnce(endpoint.url, BURST.timeoutMs);
    if (rtt == null) lost++; else rtts.push(rtt);
    const wait = BURST.gapMs - (performance.now() - t0);
    if (i < BURST.samples - 1 && wait > 0) await sleep(wait);
  }
  if (!rtts.length) return { t, offline: true, total: BURST.samples, lost, rtts: [], endpointId: endpoint.id };
  return { t, offline: false, total: BURST.samples, lost, rtts, endpointId: endpoint.id };
}

function buildSnapshot(burst, smoothedLossPct) {
  if (burst.offline) {
    return {
      t: burst.t, state: 'offline', rtt: null, jitter: null,
      lossBurst: 100, lossSmoothed: smoothedLossPct, mos: null, bands: null,
      endpointId: burst.endpointId,
    };
  }
  const rtt = median(burst.rtts);
  const jitter = jitterOf(burst.rtts);
  const lossBurst = (100 * burst.lost) / burst.total;
  const { state, mos, bands } = classify({ rtt, jitter }, smoothedLossPct);
  return { t: burst.t, state, rtt, jitter, lossBurst, lossSmoothed: smoothedLossPct, mos, bands, endpointId: burst.endpointId };
}

const compact = (s) => ({
  t: s.t,
  s: s.state,
  r: s.rtt == null ? null : Math.round(s.rtt * 10) / 10,
  j: s.jitter == null ? null : Math.round(s.jitter * 10) / 10,
  l: Math.round(s.lossBurst * 10) / 10,
  m: s.mos == null ? null : Math.round(s.mos * 100) / 100,
});

// ---------------------------------------------------------------- main cycle

function measureAndUpdate(reason) {
  if (inflight) return inflight;
  inflight = doMeasure(reason)
    .catch((e) => { console.error('NQM burst failed', e); return null; })
    .finally(() => { inflight = null; });
  return inflight;
}

async function doMeasure(reason) {
  const settings = await getSettings();
  if (settings.paused && reason !== 'manual') {
    await setVisualState('paused', null, settings);
    return null;
  }

  const burst = await runBurst(endpointOrder(settings));
  const sess = await chrome.storage.session.get({ recent: [], notif: null });

  // Loss resolution per burst is coarse (1/16 = 6.25%), so classification uses a
  // rolling window. After an offline burst the window resets so recovery shows fast.
  const recent = burst.offline
    ? []
    : [...(sess.recent || []), { lost: burst.lost, total: burst.total }].slice(-RECENT_BURSTS);
  const sums = recent.reduce((a, r) => ({ l: a.l + r.lost, t: a.t + r.total }), { l: 0, t: 0 });
  const smoothedLoss = burst.offline ? 100 : sums.t ? (100 * sums.l) / sums.t : 0;

  const snap = buildSnapshot(burst, smoothedLoss);

  const { history = [] } = await chrome.storage.local.get('history');
  history.push(compact(snap));
  while (history.length > HISTORY_MAX) history.shift();

  const notif = await maybeNotify(sess.notif, snap, settings);

  await Promise.all([
    chrome.storage.local.set({ history }),
    chrome.storage.session.set({ recent, last: snap, notif }),
  ]);

  if (!settings.paused) await setVisualState(snap.state, snap, settings);
  broadcast({ type: 'snapshot', snap });
  return snap;
}

// ---------------------------------------------------------------- toolbar icon

function drawIcon(size, stateKey) {
  const canvas = new OffscreenCanvas(size, size);
  const ctx = canvas.getContext('2d');
  const s = size / 32;
  ctx.beginPath();
  ctx.arc(16 * s, 16 * s, 15.2 * s, 0, Math.PI * 2);
  ctx.fillStyle = STATES[stateKey].color;
  ctx.fill();
  ctx.lineWidth = 1.6 * s;
  ctx.strokeStyle = 'rgba(0,0,0,.18)';
  ctx.stroke();

  ctx.fillStyle = '#fff';
  ctx.strokeStyle = '#fff';
  const bar = (x, h, alpha) => {
    ctx.globalAlpha = alpha;
    ctx.beginPath();
    ctx.roundRect(x * s, (24 - h) * s, 4.6 * s, h * s, 2 * s);
    ctx.fill();
    ctx.globalAlpha = 1;
  };

  if (stateKey === 'good') { bar(7.4, 7, 1); bar(13.7, 12, 1); bar(20, 17, 1); }
  else if (stateKey === 'fair') { bar(7.4, 7, 1); bar(13.7, 12, 1); bar(20, 17, 0.32); }
  else if (stateKey === 'bad') { bar(7.4, 7, 1); bar(13.7, 12, 0.32); bar(20, 17, 0.32); }
  else if (stateKey === 'offline') {
    ctx.lineWidth = 4 * s;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(10.5 * s, 10.5 * s); ctx.lineTo(21.5 * s, 21.5 * s);
    ctx.moveTo(21.5 * s, 10.5 * s); ctx.lineTo(10.5 * s, 21.5 * s);
    ctx.stroke();
  } else if (stateKey === 'paused') {
    ctx.beginPath(); ctx.roundRect(10.6 * s, 9 * s, 4.4 * s, 14 * s, 2 * s); ctx.fill();
    ctx.beginPath(); ctx.roundRect(17 * s, 9 * s, 4.4 * s, 14 * s, 2 * s); ctx.fill();
  } else { // unknown
    ctx.font = `bold ${19 * s}px sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('?', 16 * s, 17 * s);
  }
  return ctx.getImageData(0, 0, size, size);
}

function titleFor(stateKey, snap) {
  let title = `NQM — ${STATES[stateKey].label}`;
  if (snap && snap.rtt != null) {
    title += `\nLatency ${fmtMs(snap.rtt)} · Jitter ${fmtMs(snap.jitter)} · Loss ${fmtPct(snap.lossSmoothed)}`;
    title += `\nEstimated call quality ${fmtMos(snap.mos)} / 5`;
  }
  return title;
}

async function setVisualState(stateKey, snap, settings) {
  await chrome.action.setIcon({ imageData: { 16: drawIcon(16, stateKey), 32: drawIcon(32, stateKey) } });
  const showNum = settings.showBadge && snap && snap.rtt != null
    && ['good', 'fair', 'bad'].includes(stateKey);
  await chrome.action.setBadgeText({ text: showNum ? badgeText(snap.rtt) : '' });
  if (showNum) {
    await chrome.action.setBadgeBackgroundColor({ color: STATES[stateKey].color });
    try { await chrome.action.setBadgeTextColor({ color: '#ffffff' }); } catch {}
  }
  await chrome.action.setTitle({ title: titleFor(stateKey, snap) });
}

const badgeText = (rtt) => (rtt < 999.5 ? String(Math.round(rtt)) : '>1s');

// ---------------------------------------------------------------- notifications

const NOTIFY_COPY = {
  fair: (s) => ({
    title: '🟡 Network getting wobbly',
    message: `Latency ${fmtMs(s.rtt)} · jitter ${fmtMs(s.jitter)} · loss ${fmtPct(s.lossSmoothed)}. Calls may stutter.`,
  }),
  bad: (s) => ({
    title: '🔴 Network rough for calls',
    message: `Latency ${fmtMs(s.rtt)} · jitter ${fmtMs(s.jitter)} · loss ${fmtPct(s.lossSmoothed)}. Expect robot voice.`,
  }),
  offline: () => ({
    title: '⚫ You are offline',
    message: 'Connection lost — NQM is watching for recovery.',
  }),
  recover: (s) => ({
    title: '🟢 Good for calls again',
    message: `Back to normal — latency ${fmtMs(s.rtt)}, jitter ${fmtMs(s.jitter)}.`,
  }),
};

function fire(kind, snap) {
  const { title, message } = NOTIFY_COPY[kind](snap);
  chrome.notifications.create('nqm-state', {
    type: 'basic',
    iconUrl: chrome.runtime.getURL('icons/icon128.png'),
    title,
    message,
    priority: 1,
  });
}

// Hysteresis: red/offline alert immediately; amber needs 2 consecutive bursts;
// recovery needs 2 consecutive better bursts. 60 s cooldown between alerts.
async function maybeNotify(notif, snap, settings) {
  const n = notif || { lastNotified: null, lastAt: 0, fairRun: 0, improveRun: 0 };
  const s = snap.state;
  if (!n.lastNotified) return { ...n, lastNotified: s }; // first burst = silent baseline

  const rank = (k) => STATES[k].rank;
  const now = Date.now();
  const canNotify = now - n.lastAt >= NOTIFY_COOLDOWN_MS;
  const out = { ...n };

  if (rank(s) > rank(out.lastNotified)) {
    out.improveRun = 0;
    if (s === 'offline' || s === 'bad') {
      if (settings.notifyDegrade && canNotify) { fire(s, snap); out.lastAt = now; }
      out.lastNotified = s;
      out.fairRun = 0;
    } else if (s === 'fair') {
      out.fairRun++;
      if (out.fairRun >= 2) {
        if (settings.notifyDegrade && canNotify) { fire('fair', snap); out.lastAt = now; }
        out.lastNotified = 'fair';
        out.fairRun = 0;
      }
    }
  } else if (rank(s) < rank(out.lastNotified)) {
    out.fairRun = 0;
    out.improveRun++;
    if (out.improveRun >= 2) {
      if (s === 'good' && settings.notifyRecover && canNotify) { fire('recover', snap); out.lastAt = now; }
      out.lastNotified = s;
      out.improveRun = 0;
    }
  } else {
    out.fairRun = 0;
    out.improveRun = 0;
  }
  return out;
}

// ---------------------------------------------------------------- live mode (popup open)

function broadcast(msg) {
  for (const port of livePorts) {
    try { port.postMessage(msg); } catch {}
  }
}

chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== 'nqm-live') return;
  livePorts.add(port);
  port.onDisconnect.addListener(() => livePorts.delete(port));
  ensureLiveLoop();
});

async function ensureLiveLoop() {
  if (liveLoopRunning) return;
  liveLoopRunning = true;
  try {
    while (livePorts.size) {
      await measureAndUpdate('live');
      await sleep(LIVE_GAP_MS);
    }
  } finally {
    liveLoopRunning = false;
  }
}

// ---------------------------------------------------------------- messages

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    if (msg?.type === 'getState') {
      const [settings, sess, { history = [] }] = await Promise.all([
        getSettings(),
        chrome.storage.session.get('last'),
        chrome.storage.local.get('history'),
      ]);
      sendResponse({ settings, last: sess.last || null, history: history.slice(-240) });
    } else if (msg?.type === 'testNow') {
      const snap = await measureAndUpdate('manual');
      sendResponse({ snap });
    } else if (msg?.type === 'updateSettings') {
      const prev = await getSettings();
      const settings = { ...prev, ...msg.settings };
      await chrome.storage.local.set({ settings });
      await applySchedule(settings);
      if (prev.paused && !settings.paused) {
        measureAndUpdate('manual');
      } else if (!prev.paused && settings.paused) {
        await setVisualState('paused', null, settings);
      } else if (!settings.paused) {
        const { last } = await chrome.storage.session.get('last');
        if (last) await setVisualState(last.state, last, settings); // refresh badge toggle etc.
      }
      sendResponse({ settings });
    }
  })();
  return true;
});

// ---------------------------------------------------------------- scheduling

async function applySchedule(settings) {
  await chrome.alarms.clear(ALARM);
  if (!settings.paused) {
    chrome.alarms.create(ALARM, { periodInMinutes: Math.max(0.5, settings.intervalSec / 60) });
  }
}

async function init() {
  const settings = await getSettings();
  await chrome.storage.local.set({ settings });
  await applySchedule(settings);
  const { last } = await chrome.storage.session.get('last');
  if (!last) await setVisualState(settings.paused ? 'paused' : 'unknown', null, settings);
  measureAndUpdate('init');
}

chrome.runtime.onInstalled.addListener(init);
chrome.runtime.onStartup.addListener(init);
chrome.alarms.onAlarm.addListener((a) => { if (a.name === ALARM) measureAndUpdate('alarm'); });

// React quickly to OS-level connectivity flips (probe confirms either way).
try {
  self.addEventListener('offline', () => measureAndUpdate('offline-event'));
  self.addEventListener('online', () => measureAndUpdate('online-event'));
} catch {}
