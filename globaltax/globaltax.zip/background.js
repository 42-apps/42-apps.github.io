/* GlobalTax — background service worker.
   Opens the full-tab GlobalTax explorer when the toolbar icon is clicked. */
chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({ url: chrome.runtime.getURL('taxglobe.html') });
});
